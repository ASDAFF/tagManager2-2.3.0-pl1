<?php
require_once (dirname(dirname(__FILE__)) . '/tagmanager.class.php');
class tagManager_mysql extends tagManager {}